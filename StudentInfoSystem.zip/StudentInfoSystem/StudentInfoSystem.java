import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;

public class StudentInfoSystem extends JFrame {
    private JTextField tfName, tfID, tfCourse;
    private DefaultTableModel tableModel;
    private JTable table;

    public StudentInfoSystem() {
        setTitle("Student Information System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lblID = new JLabel("Student ID:");
        lblID.setBounds(20, 20, 100, 25);
        add(lblID);

        tfID = new JTextField();
        tfID.setBounds(120, 20, 150, 25);
        add(tfID);

        JLabel lblName = new JLabel("Name:");
        lblName.setBounds(20, 60, 100, 25);
        add(lblName);

        tfName = new JTextField();
        tfName.setBounds(120, 60, 150, 25);
        add(tfName);

        JLabel lblCourse = new JLabel("Course:");
        lblCourse.setBounds(20, 100, 100, 25);
        add(lblCourse);

        tfCourse = new JTextField();
        tfCourse.setBounds(120, 100, 150, 25);
        add(tfCourse);

        JButton btnAdd = new JButton("Add");
        btnAdd.setBounds(20, 140, 80, 30);
        add(btnAdd);

        JButton btnUpdate = new JButton("Update");
        btnUpdate.setBounds(110, 140, 80, 30);
        add(btnUpdate);

        JButton btnDelete = new JButton("Delete");
        btnDelete.setBounds(200, 140, 80, 30);
        add(btnDelete);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Student ID");
        tableModel.addColumn("Name");
        tableModel.addColumn("Course");

        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(300, 20, 270, 300);
        add(scrollPane);

        btnAdd.addActionListener(e -> {
            String id = tfID.getText();
            String name = tfName.getText();
            String course = tfCourse.getText();

            if (!id.isEmpty() && !name.isEmpty() && !course.isEmpty()) {
                tableModel.addRow(new Object[]{id, name, course});
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Please fill all fields");
            }
        });

        btnUpdate.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                tableModel.setValueAt(tfID.getText(), selectedRow, 0);
                tableModel.setValueAt(tfName.getText(), selectedRow, 1);
                tableModel.setValueAt(tfCourse.getText(), selectedRow, 2);
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Select a row to update");
            }
        });

        btnDelete.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                tableModel.removeRow(selectedRow);
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Select a row to delete");
            }
        });

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                tfID.setText(tableModel.getValueAt(selectedRow, 0).toString());
                tfName.setText(tableModel.getValueAt(selectedRow, 1).toString());
                tfCourse.setText(tableModel.getValueAt(selectedRow, 2).toString());
            }
        });

        setVisible(true);
    }

    private void clearFields() {
        tfID.setText("");
        tfName.setText("");
        tfCourse.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StudentInfoSystem::new);
    }
}