import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class BankAccountTest {
    private BankAccount account;

    @Before
    public void setUp() {
        account = new BankAccount("John Doe", 1000.0);
    }

    @Test
    public void testDeposit() {
        account.deposit(500);
        assertEquals(1500.0, account.getBalance(), 0.01);
    }

    @Test
    public void testWithdrawSuccess() {
        boolean result = account.withdraw(200);
        assertTrue(result);
        assertEquals(800.0, account.getBalance(), 0.01);
    }

    @Test
    public void testWithdrawFail() {
        boolean result = account.withdraw(1500);
        assertFalse(result);
        assertEquals(1000.0, account.getBalance(), 0.01);
    }
}