import java.io.*;
import java.net.*;
import java.util.*;

public class ChatServer {
    private static final int PORT = 2345;
    private static ArrayList<PrintWriter> clientWriters = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        System.out.println("🔵 Server started on port " + PORT);
        ServerSocket serverSocket = new ServerSocket(PORT);

        while (true) {
            Socket clientSocket = serverSocket.accept();
            System.out.println("🟢 New client connected: " + clientSocket);
            new ClientHandler(clientSocket).start();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);
                clientWriters.add(out);

                String message;
                while ((message = in.readLine()) != null) {
                    System.out.println("📩 Message: " + message);
                    for (PrintWriter writer : clientWriters) {
                        writer.println(message);
                    }
                }
            } catch (IOException e) {
                System.out.println("❌ A client disconnected.");
            } finally {
                try { socket.close(); } catch (IOException e) {}
                clientWriters.remove(out);
            }
        }
    }
}