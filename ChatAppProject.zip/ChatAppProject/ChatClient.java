import java.io.*;
import java.net.*;

public class ChatClient {
    public static void main(String[] args) throws Exception {
        BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter your name: ");
        String name = keyboard.readLine();

        Socket socket = new Socket("localhost", 2345);
        System.out.println("🟢 Connected to chat server");

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

        // Listening thread
        new Thread(() -> {
            String serverMsg;
            try {
                while ((serverMsg = in.readLine()) != null) {
                    System.out.println(serverMsg);
                }
            } catch (IOException e) {
                System.out.println("❌ Server disconnected");
            }
        }).start();

        // Send thread
        String userMsg;
        while ((userMsg = keyboard.readLine()) != null) {
            out.println(name + ": " + userMsg);
            System.out.println("(sent): " + name + ": " + userMsg);
        }

        socket.close();
    }
}